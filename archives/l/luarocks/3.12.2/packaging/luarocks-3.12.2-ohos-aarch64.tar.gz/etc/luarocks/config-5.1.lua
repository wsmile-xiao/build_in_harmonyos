-- LuaRocks configuration

rocks_trees = {
   { name = "user", root = home .. "/.luarocks" };
   { name = "system", root = "/storage/Users/currentUser/usr/local" };
}
variables = {
   LUA_DIR = "/storage/Users/currentUser/usr/local";
   LUA_BINDIR = "/storage/Users/currentUser/usr/local/bin";
   LUA_VERSION = "5.1";
   LUA = "/storage/Users/currentUser/usr/local/bin/luajit";
}
