# jpdfbookmarks 2.5.4 Debug Package

This is the debug package for jpdfbookmarks 2.5.4 on OpenHarmony aarch64.

## Notes
jpdfbookmarks is a Java application. There are no ELF debug symbols to strip.
This debug package contains debugging configuration and notes.

## Java Debugging
To enable Java debugging, set the following JVM options:
- `-Djava.util.logging.config.file=<path>/conf/jpdfbookmarks.logging.properties`
- Add `-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=5005` for remote debugging

## Runtime Dependencies
- JDK 17.0.13 (BiSheng) or compatible JDK
- JAVA_HOME environment variable required
