/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_GRAM_H_INCLUDED
# define YY_YY_GRAM_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    VAR = 258,                     /* VAR  */
    EXPR = 259,                    /* EXPR  */
    ARRAY = 260,                   /* ARRAY  */
    STRUCT = 261,                  /* STRUCT  */
    UNION = 262,                   /* UNION  */
    ENUM = 263,                    /* ENUM  */
    COMP = 264,                    /* COMP  */
    HASH = 265,                    /* HASH  */
    SEMI = 266,                    /* SEMI  */
    MOD = 267,                     /* MOD  */
    OC = 268,                      /* OC  */
    CC = 269,                      /* CC  */
    DOLLAR = 270,                  /* DOLLAR  */
    DOTDOTDOT = 271,               /* DOTDOTDOT  */
    ENDFILE = 272,                 /* ENDFILE  */
    GLOBAL = 273,                  /* GLOBAL  */
    AUTO = 274,                    /* AUTO  */
    STATIC = 275,                  /* STATIC  */
    CONST = 276,                   /* CONST  */
    POLY = 277,                    /* POLY  */
    INTEGER = 278,                 /* INTEGER  */
    NATURAL = 279,                 /* NATURAL  */
    RATIONAL = 280,                /* RATIONAL  */
    REAL = 281,                    /* REAL  */
    COMPLEX = 282,                 /* COMPLEX  */
    STRING = 283,                  /* STRING  */
    FOREIGN = 284,                 /* FOREIGN  */
    FILET = 285,                   /* FILET  */
    MUTEX = 286,                   /* MUTEX  */
    SEMAPHORE = 287,               /* SEMAPHORE  */
    CONTINUATION = 288,            /* CONTINUATION  */
    THREAD = 289,                  /* THREAD  */
    VOID = 290,                    /* VOID  */
    BOOL = 291,                    /* BOOL  */
    FUNCTION = 292,                /* FUNCTION  */
    FUNC = 293,                    /* FUNC  */
    EXCEPTION = 294,               /* EXCEPTION  */
    RAISE = 295,                   /* RAISE  */
    TYPEDEF = 296,                 /* TYPEDEF  */
    IMPORT = 297,                  /* IMPORT  */
    NEW = 298,                     /* NEW  */
    ANONINIT = 299,                /* ANONINIT  */
    NAMESPACE = 300,               /* NAMESPACE  */
    PUBLIC = 301,                  /* PUBLIC  */
    PROTECTED = 302,               /* PROTECTED  */
    EXTEND = 303,                  /* EXTEND  */
    WHILE = 304,                   /* WHILE  */
    DO = 305,                      /* DO  */
    FOR = 306,                     /* FOR  */
    SWITCH = 307,                  /* SWITCH  */
    BREAK = 308,                   /* BREAK  */
    CONTINUE = 309,                /* CONTINUE  */
    RETURNTOK = 310,               /* RETURNTOK  */
    FORK = 311,                    /* FORK  */
    CASE = 312,                    /* CASE  */
    DEFAULT = 313,                 /* DEFAULT  */
    TWIXT = 314,                   /* TWIXT  */
    NAME = 315,                    /* NAME  */
    TYPENAME = 316,                /* TYPENAME  */
    NAMESPACENAME = 317,           /* NAMESPACENAME  */
    COMMAND = 318,                 /* COMMAND  */
    NAMECOMMAND = 319,             /* NAMECOMMAND  */
    TEN_NUM = 320,                 /* TEN_NUM  */
    OCTAL0_NUM = 321,              /* OCTAL0_NUM  */
    OCTAL_NUM = 322,               /* OCTAL_NUM  */
    BINARY_NUM = 323,              /* BINARY_NUM  */
    HEX_NUM = 324,                 /* HEX_NUM  */
    TEN_FLOAT = 325,               /* TEN_FLOAT  */
    OCTAL0_FLOAT = 326,            /* OCTAL0_FLOAT  */
    OCTAL_FLOAT = 327,             /* OCTAL_FLOAT  */
    BINARY_FLOAT = 328,            /* BINARY_FLOAT  */
    HEX_FLOAT = 329,               /* HEX_FLOAT  */
    CHAR_CONST = 330,              /* CHAR_CONST  */
    STRING_CONST = 331,            /* STRING_CONST  */
    POLY_CONST = 332,              /* POLY_CONST  */
    THREAD_CONST = 333,            /* THREAD_CONST  */
    COMMENT_CONST = 334,           /* COMMENT_CONST  */
    VOIDVAL = 335,                 /* VOIDVAL  */
    BOOLVAL = 336,                 /* BOOLVAL  */
    DARROW = 337,                  /* DARROW  */
    ISTYPE = 338,                  /* ISTYPE  */
    HASMEMBER = 339,               /* HASMEMBER  */
    POUND = 340,                   /* POUND  */
    COMMA = 341,                   /* COMMA  */
    ASSIGN = 342,                  /* ASSIGN  */
    ASSIGNPLUS = 343,              /* ASSIGNPLUS  */
    ASSIGNMINUS = 344,             /* ASSIGNMINUS  */
    ASSIGNTIMES = 345,             /* ASSIGNTIMES  */
    ASSIGNDIVIDE = 346,            /* ASSIGNDIVIDE  */
    ASSIGNDIV = 347,               /* ASSIGNDIV  */
    ASSIGNMOD = 348,               /* ASSIGNMOD  */
    ASSIGNPOW = 349,               /* ASSIGNPOW  */
    ASSIGNSHIFTL = 350,            /* ASSIGNSHIFTL  */
    ASSIGNSHIFTR = 351,            /* ASSIGNSHIFTR  */
    ASSIGNLXOR = 352,              /* ASSIGNLXOR  */
    ASSIGNLAND = 353,              /* ASSIGNLAND  */
    ASSIGNLOR = 354,               /* ASSIGNLOR  */
    ASSIGNOR = 355,                /* ASSIGNOR  */
    ASSIGNAND = 356,               /* ASSIGNAND  */
    QUEST = 357,                   /* QUEST  */
    COLON = 358,                   /* COLON  */
    OR = 359,                      /* OR  */
    AND = 360,                     /* AND  */
    LOR = 361,                     /* LOR  */
    LXOR = 362,                    /* LXOR  */
    LAND = 363,                    /* LAND  */
    EQ = 364,                      /* EQ  */
    NE = 365,                      /* NE  */
    LT = 366,                      /* LT  */
    GT = 367,                      /* GT  */
    LE = 368,                      /* LE  */
    GE = 369,                      /* GE  */
    SHIFTL = 370,                  /* SHIFTL  */
    SHIFTR = 371,                  /* SHIFTR  */
    PLUS = 372,                    /* PLUS  */
    MINUS = 373,                   /* MINUS  */
    TIMES = 374,                   /* TIMES  */
    DIVIDE = 375,                  /* DIVIDE  */
    DIV = 376,                     /* DIV  */
    POW = 377,                     /* POW  */
    STARSTAR = 378,                /* STARSTAR  */
    POW2 = 379,                    /* POW2  */
    POW3 = 380,                    /* POW3  */
    UNIONCAST = 381,               /* UNIONCAST  */
    UMINUS = 382,                  /* UMINUS  */
    BANG = 383,                    /* BANG  */
    FACT = 384,                    /* FACT  */
    LNOT = 385,                    /* LNOT  */
    INC = 386,                     /* INC  */
    DEC = 387,                     /* DEC  */
    STAR = 388,                    /* STAR  */
    AMPER = 389,                   /* AMPER  */
    THREADID = 390,                /* THREADID  */
    OS = 391,                      /* OS  */
    CS = 392,                      /* CS  */
    DOT = 393,                     /* DOT  */
    ARROW = 394,                   /* ARROW  */
    STAROS = 395,                  /* STAROS  */
    CALL = 396,                    /* CALL  */
    OP = 397,                      /* OP  */
    CP = 398,                      /* CP  */
    POINTER = 399,                 /* POINTER  */
    COLONCOLON = 400,              /* COLONCOLON  */
    IF = 401,                      /* IF  */
    TRY = 402,                     /* TRY  */
    NONL = 403,                    /* NONL  */
    ELSE = 404,                    /* ELSE  */
    CATCH = 405,                   /* CATCH  */
    NL = 406                       /* NL  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 71 "../gram.y"

    int		    ints;
    Value	    value;
    Class	    class;
    ArgType	    *argType;
    Type	    *type;
    Publish	    publish;
    ExprPtr	    expr;
    Atom	    atom;
    DeclListPtr	    declList;
    MemListPtr	    memList;
    Fulltype	    fulltype;
    ArgDecl	    argDecl;
    SymbolPtr	    symbol;
    NamespacePtr    namespace;
    CodePtr	    code;
    Bool	    boolean;
    AtomListPtr	    atomList;
    FuncDecl	    funcDecl;

#line 236 "gram.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_GRAM_H_INCLUDED  */
