#!/bin/bash

python "$@"
