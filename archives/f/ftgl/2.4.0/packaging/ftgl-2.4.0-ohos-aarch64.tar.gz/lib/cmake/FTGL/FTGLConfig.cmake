include("${CMAKE_CURRENT_LIST_DIR}/FTGL-targets.cmake")

set(FTGL_INCLUDE_DIR "/storage/Users/currentUser/usr/local/include")
set(FTGL_LIBRARY     ftgl)

set(FTGL_INCLUDE_DIRS ${FTGL_SOURCE_DIR})
set(FTGL_LIBRARIES    ${FTGL_LIBRARY})
