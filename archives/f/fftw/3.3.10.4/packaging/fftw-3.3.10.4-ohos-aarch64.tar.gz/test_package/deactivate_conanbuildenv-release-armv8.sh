echo Restoring environment
export PATH='/data/app/el1/rde/llvm/bin:/storage/Users/currentUser/.local/bin:/data/app/el1/rde/bin:/data/service/hnp/openssh.org/openssh_10.0p1/bin:/data/service/hnp/openssh.org/openssh_10.0p1/sbin:/data/app/bin:/data/app/spool/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:/system/bin:/system/xbin:/data/service/hnp/bin:/storage/Users/currentUser/.local/bin:/storage/Users/currentUser/bin:/storage/Users/currentUser/.opendesk/bin'
export SHELL='/usr/bin/zsh'
unset CONFIG_SHELL
