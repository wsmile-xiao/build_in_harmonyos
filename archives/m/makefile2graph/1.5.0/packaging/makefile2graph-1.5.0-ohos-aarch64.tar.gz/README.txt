makefile2graph v1.5.0 - CI will build actual package
