// MIT License
//
// Copyright (c) 2018-2025 Jakub Melka and Contributors
//
// OHOS adaptation: stub implementation using QPainter instead of Blend2D
// When blend2d is not available, this provides a fallback PDFBLPaintDevice

#ifndef PDFBLPAINTER_H
#define PDFBLPAINTER_H

#include "pdfglobal.h"

#include <QImage>
#include <QPaintDevice>
#include <QPainter>

namespace pdf
{

/// Stub implementation of PDFBLPaintDevice using QPainter
/// This is used when blend2d is not available on the target platform (e.g., OHOS)
class PDFBLPaintDevice : public QPaintDevice
{
public:
    PDFBLPaintDevice(QImage& offscreenBuffer, bool isMultithreaded);
    ~PDFBLPaintDevice() override;

    int devType() const override;
    QPaintEngine* paintEngine() const override;

    /// Returns 0 since blend2d is not available
    static uint32_t getVersion() { return 0; }

    int metric(PaintDeviceMetric metric) const override;

private:
    QImage& m_offscreenBuffer;
    QPainter* m_painter;
};

}   // namespace pdf

#endif // PDFBLPAINTER_H