#!/bin/sh
# pkg-config portable activation script — HarmonyOS (toybox ash compatible)
# Usage: . /path/to/pkg-config-0.29.2-ohos-aarch64/activate.sh

if [ -n "$_PKGCONFIG_PORTABLE_OLD_PATH" ]; then
    echo "Already activated."
    return 2>/dev/null || exit 0
fi

_PKGCONFIG_PORTABLE_DIR="$(cd "$(dirname "$0")" && pwd)"

# Save old env
_PKGCONFIG_PORTABLE_OLD_PATH="${PATH:-}"
_PKGCONFIG_PORTABLE_OLD_LD="${LD_LIBRARY_PATH:-}"
_PKGCONFIG_PORTABLE_OLD_PC="${PKG_CONFIG_PATH:-}"

# Set new env
export PATH="$_PKGCONFIG_PORTABLE_DIR/bin:${PATH:-}"
export LD_LIBRARY_PATH="$_PKGCONFIG_PORTABLE_DIR/lib${_PKGCONFIG_PORTABLE_OLD_LD:+:$_PKGCONFIG_PORTABLE_OLD_LD}"
export PKG_CONFIG_PATH="$_PKGCONFIG_PORTABLE_DIR/lib/pkgconfig:${_PKGCONFIG_PORTABLE_OLD_PC:-}${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"

echo "pkg-config ${PKG_VERSION:-0.29.2} portable environment activated"
echo "  Prefix: $_PKGCONFIG_PORTABLE_DIR"

deactivate_pkgconfig() {
    export PATH="$_PKGCONFIG_PORTABLE_OLD_PATH"
    export LD_LIBRARY_PATH="$_PKGCONFIG_PORTABLE_OLD_LD"
    export PKG_CONFIG_PATH="$_PKGCONFIG_PORTABLE_OLD_PC"
    unset _PKGCONFIG_PORTABLE_DIR _PKGCONFIG_PORTABLE_OLD_PATH
    unset _PKGCONFIG_PORTABLE_OLD_LD _PKGCONFIG_PORTABLE_OLD_PC
    unset -f deactivate_pkgconfig
    echo "Deactivated."
}
