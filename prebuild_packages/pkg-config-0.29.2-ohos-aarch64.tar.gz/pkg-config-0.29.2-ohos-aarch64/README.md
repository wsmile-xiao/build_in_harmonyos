# pkg-config 0.29.2 Portable for HarmonyOS

> **Platform**: HarmonyOS aarch64 (musl) | **Build**: 2026-04-04

## Quick Start

```bash
# 1. Extract
tar xzf pkg-config-0.29.2-ohos-aarch64.tar.gz -C ~/usr/

# 2. ⚠️ Fix permissions (HarmonyOS signing requirement)
find pkg-config-0.29.2-ohos-aarch64/ -type f -name '*.so*' -exec chmod +x {} \;
chmod +x pkg-config-0.29.2-ohos-aarch64/bin/*

# 3. Activate
. ~/pkg-config-0.29.2-ohos-aarch64/activate.sh

# 4. Use
pkg-config --version

# 5. Deactivate
deactivate_pkgconfig
```

> ⚠️ **chmod +x required**: HarmonyOS adhoc signing resets executable bits.
> This is a known platform limitation, not a packaging error.

## Directory Structure

```
pkg-config-0.29.2-ohos-aarch64/
├── activate.sh              # Environment activation (source this)
├── README.md
├── bin/
│   ├── pkg-config           # Main binary (ELF, signed, stripped)
│   └── aarch64-unknown-linux-ohos-pkg-config  # Alias
├── lib/
│   └── external/            # External dependencies (if any)
└── share/
    ├── aclocal/pkg.m4      # Autoconf m4 macro
    └── man/man1/pkg-config.1  # Man page
```

## Features

- Self-contained with $ORIGIN RPATH (works from any location)
- ELF files stripped and signed for HarmonyOS
- toybox ash compatible (no bashisms)
- Internal GLib (no external GLib dependency)

## Build Notes

- Compiled with clang 15.0.4 (LLVM toolchain)
- Uses internal GLib 2.38.2 (--with-internal-glib)
- Patched glib Makefile: removed -Werror flags for clang compatibility
